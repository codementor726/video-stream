package com.qboxus.musictok.Models;

import java.io.Serializable;

public class UserRegisterModel implements Serializable {

    public String socailId, socailType, fname, lname, email, dateOfBirth, phoneNo, password, username, authTokon, picture;
}
