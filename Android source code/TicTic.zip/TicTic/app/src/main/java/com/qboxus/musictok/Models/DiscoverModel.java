package com.qboxus.musictok.Models;

import java.util.ArrayList;

/**
 * Created by qboxus on 3/1/2019.
 */

public class DiscoverModel {

    public String id, title, views, videos_count, fav;

    public ArrayList<HomeModel> arrayList;

}
