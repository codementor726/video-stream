package com.qboxus.musictok.ActivitesFragment.SendGift;

import java.io.Serializable;

public class StickerModel implements Serializable {
    public String id,image,name,coins="0" ;
    public boolean isSelected;
    public int count;
}
