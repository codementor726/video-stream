package com.qboxus.musictok.TrimModule;

public enum TrimType {
    DEFAULT, FIXED_DURATION, MIN_DURATION, MIN_MAX_DURATION
}
