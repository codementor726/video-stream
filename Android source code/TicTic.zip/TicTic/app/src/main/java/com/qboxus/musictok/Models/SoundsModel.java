package com.qboxus.musictok.Models;


/**
 * Created by qboxus on 2/22/2019.
 */


public class SoundsModel {

    public String id, sound_name, description, section, thum, duration, date_created, fav;
    public String acc_path;

}
