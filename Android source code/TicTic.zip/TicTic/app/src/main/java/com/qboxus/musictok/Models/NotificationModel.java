package com.qboxus.musictok.Models;

/**
 * Created by qboxus on 2/25/2019.
 */

public class NotificationModel {

    public String user_id, username, first_name, last_name, profile_pic, effected_fb_id, type;
    public String video_id, video, thum, gif, created;

    public String id, string;


}
