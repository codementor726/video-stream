package com.qboxus.musictok.Models;

public class FollowingModel {

    public String fb_id, username, first_name, last_name, gender, profile_pic, bio;
    public String follow_status_button;
    public boolean is_select,isFollow;
    public String notificationType;
    public String gifLink;


}
