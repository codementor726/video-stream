package com.qboxus.musictok.Models;

public class SliderModel {

    public String id, image, url;
}