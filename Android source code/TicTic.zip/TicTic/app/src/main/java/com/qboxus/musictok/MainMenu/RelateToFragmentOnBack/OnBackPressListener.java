package com.qboxus.musictok.MainMenu.RelateToFragmentOnBack;

/**
 * Created by qboxus on 3/30/2018.
 */

public interface OnBackPressListener {
     boolean onBackPressed();
}
